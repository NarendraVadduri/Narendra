package stepDefinitions;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;

import pageObjects.SearchCustPage;
import pageObjects.addCustomerPage;
import pageObjects.loginPage;

public class baseClass {
	
	public WebDriver driver;
	public loginPage lp;
	public addCustomerPage addcust;
	public SearchCustPage searchcust;
	
	public static String randomString() {
		String generatestring1 = RandomStringUtils.randomAlphabetic(5);
		return(generatestring1);
	}

}
