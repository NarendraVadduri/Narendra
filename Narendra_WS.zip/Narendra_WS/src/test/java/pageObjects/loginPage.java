package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;


public class loginPage {

	public WebDriver ldriver;
	
	public loginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	@FindBy (id = "Email")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy (id = "Password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy (css = "button[type='submit']")
	@CacheLookup
	WebElement bthLogin;
	
	@FindBy (linkText = "Logout")
	@CacheLookup
	WebElement lnkLogout;
	
	public void setUserName(String uname) {
		txtEmail.clear();
		txtEmail.sendKeys(uname);
				
	}
	
	public void setPassword(String pwd) {
		txtPassword.clear();
		txtPassword.sendKeys(pwd);
			
	}
	
	public void clickLogin() {
		bthLogin.click();
				
	}
	public void clickLogout() {
		lnkLogout.click();
				
	}
	
}
